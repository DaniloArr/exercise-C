#include <stdio.h>

main()
{
    int lar;
    float compra;

    printf("Digite a quantidade de laranjas: ");
    scanf("%d",&lar);

    if((lar > 0) && (lar < 12))
    {
        compra = lar * 0.35;
        printf("O valor da compra foi: R$ %.2f",compra);
    }

    else if(lar >= 12)
    {
        compra = lar * 0.30;
        printf("O valor da compra foi: R$ %.2f",compra);
    }

    else
    {
    printf("Compra Invalida");
    }

    return 0;
}
