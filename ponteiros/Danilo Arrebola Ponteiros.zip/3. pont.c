#include <stdio.h>

int calculo(int *A, int *B)
{
    return *B = *A * 2;
}

int main()
{
    int a, b;

    printf("Insira um valor: ");
    scanf("%i", &a);

    calculo(&a, &b);

    printf("Valor inicial: %i, valor calculado: %i", a, b);
}