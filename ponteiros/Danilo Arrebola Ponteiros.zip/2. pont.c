#include <stdio.h>

int trocas(int *A, int *B)
{
    int Z;
    printf("Digite um valor para A: ");
    scanf("%i", &*A);
    printf("Digite um valor para B: ");
    scanf("%i", &*B);

    Z = *A;
    *A = *B;
    *B = Z;

    return *A, *B;
}

int main()
{
    int trocA, trocB;
    trocas(&trocA, &trocB);

    printf("O novo valor de A: %i\n", trocA);
    printf("O novo valor de B: %i\n", trocB);
}