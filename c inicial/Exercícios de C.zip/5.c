#include <stdio.h>
main()
{
   float nota1, nota2, nota3, p1=2, p2=3 , p3=5 , media;

   printf("Digite o valor da Primeira Nota: ");
   scanf("%f",&nota1);
   printf("Digite o valor da Segunda Nota: ");
   scanf("%f",&nota2);
   printf("Digite o valor da Terceira Nota: ");
   scanf("%f",&nota3);

   media = (nota1*p1 + nota2*p2 + nota3*p3)/(p1+p2+p3);

   printf("A Media das Notas:%.2f",media);

}
